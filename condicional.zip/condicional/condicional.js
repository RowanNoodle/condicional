function media(){
var val1 =document.getElementById ('val1').value;
var val2 =document.getElementById ('val2').value;
var result = (parseInt(val1) + parseInt(val2)) /2;
if (result>= 6)
alert ('sua media foi'+result+'aprovado')
else
alert ("sua media de merda foi" +result+ "reprovado burro")
}

function comparacao(){
    var val1 =document.getElementById ('val1').value;
    var val2 =document.getElementById ('val2').value;
    if(val1==val2)
     alert ('é igual os dois')
    else
    if(val1>val2)
     
    alert ('valor 1 é maior que o valor 2')
    else
    alert ('valor 2 é maior que o valor 1')
}